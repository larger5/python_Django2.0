from django.contrib import admin
from .models import  BookInfo,HeroInfo,HeroInfo # 注意 model 前面有一个点

class HeroInfoInline(admin.TabularInline):# StackedInline 属性占一行、TabularInline 属性表格形式
    model = HeroInfo
    # 添加的时候显示的个数，可再增加
    extra = 2

# 设置模型列表显示的字段
class BookAdmin(admin.ModelAdmin):
    # 显示
    list_display = ['id','btitle','bpub_date']
    # 过滤
    list_filter = ['btitle']
    # 搜索
    search_fields = ['btitle']
    # 分组显示
    fieldsets = [
        ('basic',{'fields': ['btitle']}),
        ('more', {'fields': ['bpub_date']}),
    ]
    # 外键
    inlines = [HeroInfoInline]

# 注册到后台管理
admin.site.register(BookInfo,BookAdmin)
admin.site.register(HeroInfo)

