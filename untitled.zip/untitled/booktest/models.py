from django.db import models

# 和 Hibernate 差不多，不用写 sql 语句，全靠映射

class BookInfo(models.Model):

    # 字段 = 数据库字段类型
    btitle = models.CharField(max_length=20)

    bpub_date = models.DateTimeField()

    # 方法不需要偏移
    def __str__(self):
        return "%d" % self.pk

class HeroInfo(models.Model):
    hname = models.CharField(max_length=20)

    hgender = models.BooleanField() # models.NullBooleanField 含 Null

    hcontent = models.CharField(max_length=100)

    # 外键（模型名，Django 2.0 必填、这里选择 级联删除）
    hBook = models.ForeignKey('BookInfo',on_delete=models.CASCADE) # 去掉引号也是可以的

    # 方法不需要偏移
    def __str__(self):
        return "%d" % self.pk