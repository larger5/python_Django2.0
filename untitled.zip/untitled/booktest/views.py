from django.shortcuts import render
from django.http import HttpResponse
from .models import *

# 视图
def hello(request):
    return HttpResponse("<span style='color:red'>Hello world</span>")   # 显示红色的字符串

# 模板
def index(request):
    bookList=BookInfo.objects.all()
    context={"booklist":bookList}
    return render(request,"booktest/index.html",context)

# 页面请求处理
def detail(reqeust, id):
    book = BookInfo.objects.get(pk=id)
    context = {'book': book}
    return render(reqeust, 'booktest/detail.html',context)
